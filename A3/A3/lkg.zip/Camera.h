#ifndef __CAMERA_H__
#define __CAMERA_H__
#include "Angel.h"

class Camera {

public:
	Camera();
	~Camera();
	mat4 getCameraMatrix() { return camera_matrix; }
	void pitch(GLfloat theta);
	void roll(GLfloat theta);
	void yaw(GLfloat theta);
	void zoom(GLfloat dist);

private:
	mat4 camera_matrix;
	vec4 eye;
	vec4 u;
	vec4 v;	// this is "up"
	vec4 n;



};

#endif
