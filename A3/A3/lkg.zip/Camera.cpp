#include "Camera.h"


Camera::Camera()
{
	camera_matrix = Translate(0.5f, 0, 0);
	//eye = vec4(0.5f, 0, -20.0f, 0);
	////u = ;
	//v = vec4(0, 1.0f, 0, 0);
	//n = vec4(0, 0, 0, 0);
	//camera_matrix = LookAt(eye, eye - n, v);
}


Camera::~Camera()
{

}


void Camera::pitch(GLfloat theta)
{
	v = v * cos(theta) - n * sin(theta);
	n = v * sin(theta) + n * cos(theta);
}

void Camera::roll(GLfloat theta)
{

}

void Camera::yaw(GLfloat theta)
{

}

void Camera::zoom(GLfloat dist)
{

}